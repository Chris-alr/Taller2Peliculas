<template>
<article class="info-card">
    <span class="info-title">{{ movie.title }} </span>
</article>
	<article class="info-card" >

		<div class="container">

			<img class="info-image" :src="movie.poster_path" />
			
		</div>
		
    
			
	</article>
         
                    <h1 >Genero(s) :</h1>
               
    <article class="info-card">
        
                <div>
               
                
                <div class="info-gnre" v-for="genero in movie.genres" :key="genero.name">
				{{ genero.name }}
			</div>
	
        </div>

      
    </article>
    <article class="info-card">
        <div class="info-puntuacion">
          <div>
            Puntuacion General: &#11088;{{movie.vote_average}}
        </div>
        <div>
            Cantidad de Votos : {{movie.vote_count}}
        </div>
        <div>
            Popularidad :    {{movie.popularity}}
        </div>
        </div>
    </article>
         <h1  > Sinopsis:</h1>
    <article class="info-card">

        <div>
           
           <span class="info-overview">{{movie.overview}}</span> 
        </div>
        
    </article>
</template>
<script>
export default {
	props: {
		movie: {
			type: Object,
			required: true,
		},
		onClick: {
			type: Function,
			default: () => {},
		},
		
	},
};
</script>
<style></style>
