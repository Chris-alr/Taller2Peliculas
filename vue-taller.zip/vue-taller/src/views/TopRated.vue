<template>
	<h1>Peliculas Mejor Valoradas</h1>
	<h2 v-if="isLoading">Cargando Peliculas...</h2>
	<section v-else class="movies-grid">
		<MovieCard
			v-for="movie in movies"
			:movie="movie"
			:onClick="showMovie"
		/>

		
 
	</section>
       <footer>
        	<container>

              		<button class="button-52" @click="lastPage(counter)" role="button"> Pagina Anterior</button>
					<button class="button-52" @click="nextPage(counter)" role="button">  Siguiente Pagina</button>
			
            </container>
		
    </footer>
		 
</template>
<script>
import Movie from '@/models/Movie';
import apiService from '@/services/api.service';
import MovieCard from '@/components/MovieCard.vue';
export default {
	components: {MovieCard },
	data() {
		return {
			isLoading: true,
			movies: [],
			counter: 1,
		};
	},

	mounted() {
		
		this.getTopRated(1);
	},
	methods: {
		async getTopRated(currentPage) {
			this.isLoading = true;
			const { data } = await apiService.getTopRated(currentPage);
			this.movies = await Promise.all(
				data.results.map((movi)=> this.getMovie(movi.id))
				
			);
			this.isLoading = false;
		},
		async getMovie(movieId){
			const {data} = await apiService.getMovie(movieId);
			const movieData = new Movie(data);
			return movieData;
			
		},
		showMovie(id) {
			this.$router.push({ name: 'Movie', params: { id } });
		},
		 nextPage(counter){
			this.counter=counter +1;
			console.log(this.counter);
			this.getTopRated(this.counter);
			
		},
		lastPage(counter){

			if(counter===1){
				alert( "Ya se encuentra en la primera pagina!")
			}else{

			this.counter=counter -1;
			console.log(this.counter);
			return this.getTopRated(this.counter);
			}

			
			
		}
	},
};
</script>
<style>
.movies-grid {
	padding: 1rem;
	display: grid;
	grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
	grid-auto-rows: 250px;
	gap: 1rem;
}

.buttons{
	border-radius: 20px;
	height: 100px;

}

/* CSS */
.button-52 {
		border-radius: 100px;
	height: 100px;
	width: 220px;
	margin-left: 20px;
	margin-right:20px;

  font-size: 16px;
  font-weight: 200;
  letter-spacing: 1px;
  padding: 13px 20px 13px;
  outline: 0;
  border: 1px solid black;
  cursor: pointer;
  position: relative;
  background-color: rgba(0, 0, 0, 0);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-52:after {
	border-radius: 100px;
  content: "";
  background-color: #04AA6D;;
  width: 100%;
  z-index: -1;
  position: absolute;
  height: 100%;
  top: 7px;
  left: 7px;
  transition: 0.2s;
}

.button-52:hover:after {
  top: 0px;
  left: 0px;
}

@media (min-width: 768px) {
  .button-52 {
    padding: 13px 50px 13px;
  }
}
</style>
