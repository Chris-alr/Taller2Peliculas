<template>
	<nav id="nav" class="navigationWrapper">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="topnav" id="myTopnav">
  <router-link to="/">Hogar</router-link>
  <router-link to="/about">About</router-link>
  <router-link to="/movies">Populares</router-link>
 <router-link to="/topRated">Mejor Valoradas</router-link>
 
</div>
	</nav>

	<router-view></router-view>
</template>

<script>
export default {
	computed() {},

};
</script>

<style lang="scss">
nav {
	font-size: 1.9rem;
	margin-bottom: 2rem;
	text-align: left;
	padding: 0.4rem 0.6rem;
	background-color: white;
	a {
		text-decoration: none;
		border-bottom: 2px solid transparent;
		&.router-link-active {
			color: #3eaf7c;
			border-bottom-color: #3eaf7c;
		}
		
	}
}


#app {
	font-family: Avenir, Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	text-align: center;
	color: black;
	margin-top: 1px;
	margin-left:1px;
}

/* Add a black background color to the top navigation */
.topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add an active class to highlight the current page */
.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
  display: none;
}
</style>
