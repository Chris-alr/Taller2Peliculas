<template lang>
  <div>
    <h1 align="center">Bienvenido a nuestra pagina!</h1>
    
  </div>
  <div class="wrapper">
  <div class="slider" id="slider">
    <ul class="slides">
      <li class="slide" id="slide1">
      
          
          <img src="https://image.tmdb.org/t/p/w500//lNyLSOKMMeUPr1RsL4KcRuIXwHt.jpg" alt="photo 1">
     
      </li>
      <li class="slide" id="slide2">
      
   
          <img src="https://image.tmdb.org/t/p/w500//3G6wET9eLvYn3aoIj8NfQFhpYEB.jpg" alt="photo 2">
      
      </li>
      <li class="slide" id="slide3">
       
         
          <img src="https://image.tmdb.org/t/p/w500//eeijXm3553xvuFbkPFkDG6CLCbQ.jpg" alt="photo 3">
      
      </li>
      <li class="slide" id="slide4">
       
          <img src="https://image.tmdb.org/t/p/w500//8Y43POKjjKDGI9MH89NW0NAzzp8.jpg" alt="photo 4">
  
      </li>
      <li class="slide" id="slide5">
     
          
           <img src="https://image.tmdb.org/t/p/w500//lNyLSOKMMeUPr1RsL4KcRuIXwHt.jpg" alt="photo 5">
        
      </li>
      <li class="slide">
     
      
          <img src="https://image.tmdb.org/t/p/w500//8Y43POKjjKDGI9MH89NW0NAzzp8.jpg" alt="photo 1">
        
      </li>
    </ul>
  
  </div>
</div>
<div>
  <h2>Busca de manera rapida y sencilla las peliculas mas populares y las mejor valoradas del momento!</h2>
</div>
</template>
<script>
export default {
  
}
</script>
<style >

@keyframes slide {
	0% { transform: translateX(0); }
	10% { transform: translateX(0); }

	15% { transform: translateX(-100%); }
	25% { transform: translateX(-100%); }

	30% { transform: translateX(-200%); }
	45% { transform: translateX(-200%); }

	50% { transform: translateX(-300%); }
	65% { transform: translateX(-300%); }

	70% { transform: translateX(-400%); }
	85% { transform: translateX(-400%); }

	90% { transform: translateX(-500%); }
	100% { transform: translateX(-500%); }
}

* { box-sizing: border-box; }

html { scroll-behavior: smooth; }

body {
	font-family: sans-serif;
}

.wrapper {
	max-width: 1200px;
	margin: 0 auto;
}

.slider {
	position: relative;
}

.slides {
	position: relative;
	display: flex;
	overflow: hidden;
}

.slide {
	width: 80vw;

	flex-shrink: 0;
	animation-name: slide;
	animation-duration: 30s;
	animation-iteration-count: infinite;
	animation-timing-function: linear;
}

.slides:hover .slide {
	animation-play-state: paused;
}

.slide img {
	width: 40%;
	vertical-align: top;
}

.slide a {
	width: 100%;
	display: inline-block;
	position: relative;
}



.slide:target {
	animation-name: none;
	position: absolute;
	left: 0;
	top: 0;
	right: 0;
	bottom: 0;
	z-index: 50;
}
h1 { color: black; font-family: 'Lato', sans-serif; font-size: 54px; font-weight: 300; line-height: 58px; margin: 0 0 58px; }
h2 {margin-top:40px; color: black; font-family: 'Lato', sans-serif; font-size: 45px; font-weight: 300; line-height: 58px; margin: 0 0 58px; }







@media only screen and (min-width: 1200px) {
	.slide {
		width: 1200px;
	}


}
  
</style>