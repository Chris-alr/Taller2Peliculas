<template>
	<article class="movie-card" :class="movie.genres[0].name" @click="onClick(movie.id)">
		<header>
			<span class="movie-title">{{ movie.title }} </span>
			
			
		</header>
		<div class="container">

			<img class="movie-image" :src="movie.backdrop_path" />
			<div class="bottom-right"> &#11088;{{movie.vote_average}}</div>
		</div>
		
		<footer>
			<div class="movie-gnre" v-for="genero in movie.genres" :key="genero.name">
				{{ genero.name }}
			</div>
		</footer>
	</article>
</template>
<script>
export default {
	props: {
		movie: {
			type: Object,
			required: true,
		},
		onClick: {
			type: Function,
			default: () => {},
		},
		
	},
};
</script>
<style></style>
