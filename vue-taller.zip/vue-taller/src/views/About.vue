<template>

    <h1 class="titulo">Pagina construida usando la API de </h1>
    <a class="titulo" href="https://www.themoviedb.org/">TheMovieDb</a>

    <div>
        
        <img class="movie-image" src="../assets/imagenes/movie.jpg" />
       
    </div>

   
</template>
<style>
.titulo{
    margin-top: 150px;
    font-size: 30px;
}
</style>